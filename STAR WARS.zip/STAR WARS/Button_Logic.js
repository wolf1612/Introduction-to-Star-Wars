<script language="javascript" type="text/javascript">

if(document.getElementById('button').clicked == true)
{
   alert("button was clicked");
   document.write('Hello');
}

</script>
